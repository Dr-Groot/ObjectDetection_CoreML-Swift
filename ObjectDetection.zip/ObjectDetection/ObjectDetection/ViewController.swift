//
//  ViewController.swift
//  ObjectDetection
//
//  Created by Amam Pratap Singh on 24/01/23.
//

import UIKit
import AVKit
import Vision

class ViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {

//  Idetifier label which will display the object Name + Confidence Level
    let identifierLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = .black
        label.textColor = .white
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        loadCameraAndPreview()
        setupIdentifierConfidenceLabel()
    }

//  Constraints for Identifier Label
    private func setupIdentifierConfidenceLabel() {
        view.addSubview(identifierLabel)
        identifierLabel.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -32).isActive = true
        identifierLabel.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        identifierLabel.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        identifierLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }

//  SETTING UP THE CAMERA FOR RECOGNITION USING AVCaptureSession
    private func loadCameraAndPreview() {
        let captureSession = AVCaptureSession() // Creating Capture Session
        captureSession.sessionPreset = .photo // Capture Present Style
        guard let captureDevice = AVCaptureDevice.default(for: .video) else { return } // Capture Device location is given to back camera
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else { return } // Setting up the Capture device input from the device
        captureSession.addInput(input) // Adding input to Capture Session
        captureSession.startRunning() // Starting Capture Session

        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession) // Addedd the Capture Session to preview layer
        view.layer.addSublayer(previewLayer) // Added previewLayer to View for displaying on the screen + Frame
        previewLayer.frame = view.frame

//      Capturing the data from the video frame and adding delegate.
        let dataOutput = AVCaptureVideoDataOutput()
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(dataOutput)
    }

//      Delegate method which is called everytime when camera is capturing a frame. (Basically 10 Frames per second)
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {

//      Image
        guard let pixelBuffer: CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

//      Model
        guard let model = try? VNCoreMLModel(for: Resnet50().model) else { return }

//      Request
        let request = VNCoreMLRequest(model: model) { finishRequest, error in
            guard let results = finishRequest.results as? [VNClassificationObservation] else { return }
            guard let observation = results.first else { return }
            DispatchQueue.main.async {
                self.identifierLabel.text = "\(observation.identifier) \(observation.confidence * 100)"
            }
        }

//      Handler
        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
    }
}
